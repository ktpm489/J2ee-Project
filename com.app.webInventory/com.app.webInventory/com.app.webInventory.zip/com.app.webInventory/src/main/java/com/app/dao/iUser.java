package com.app.dao;



public interface iUser {
	 public boolean checkInfo(String userName , String userPass)throws Exception ;
}
