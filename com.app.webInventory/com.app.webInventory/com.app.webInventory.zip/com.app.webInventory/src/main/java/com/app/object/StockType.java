package com.app.object;

public class StockType {

	private int stockTypeId = 0;
	private String stockTypeName = " ";
	private String stockDescription = " ";
	public int getStockTypeId() {
		return stockTypeId;
	}
	public void setStockTypeId(int stockTypeId) {
		this.stockTypeId = stockTypeId;
	}
	public String getStockTypeName() {
		return stockTypeName;
	}
	public void setStockTypeName(String stockTypeName) {
		this.stockTypeName = stockTypeName;
	}
	public String getStockDescription() {
		return stockDescription;
	}
	public void setStockDescription(String stockDescription) {
		this.stockDescription = stockDescription;
	}
}
